package avaliacao_de_goleiros;

public class Chute_Ao_Gol {
	private int id;
	private int for�a;
	private int quadrante;
	private int posi�aoX;
	private int posi�aoY;
	
	public Chute_Ao_Gol (int id, int for�a, int quadrante, int posi�aoX, int posi�aoY) {
		this.id= id;
		this.for�a= for�a;
		this.quadrante= quadrante;
		this.posi�aoX= posi�aoX;
		this.posi�aoY= posi�aoY;
	}


}
